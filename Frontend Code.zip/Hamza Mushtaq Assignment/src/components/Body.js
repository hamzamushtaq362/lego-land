import React from 'react'
import LeftSide from './LeftSide'

export default function Body() {
  return (
    <>
      <LeftSide />
    </>
  )
}
