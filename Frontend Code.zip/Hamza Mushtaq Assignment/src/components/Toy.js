import React from 'react'

export default function Toy() {
  return (
    <>
      <h1>Toys</h1>
    </>
  )
}
