import React from 'react'

export default function Character() {
  return (
    <>
      
    </>
  )
}
