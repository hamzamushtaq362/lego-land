import React from 'react'

export default function Catalog() {
  return (
    <>
      <h1>Catalog</h1>
    </>
  )
}
