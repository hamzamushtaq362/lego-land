import React from 'react'
import Body from './Body'

export default function Index() {
    return (
        <div>
            <Body />
            {/* <h1>Index</h1> */}
        </div>
    )
}
